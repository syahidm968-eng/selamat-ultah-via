# Halaman Ucapan Ulang Tahun — Novia Hidayani

Buka `index.html` di browser untuk melihat halaman ucapan animasi.

Jika ingin menambahkan musik:
1. Letakkan file `converted_music.mp3` di folder yang sama.
2. Atau ubah tag <source> di dalam HTML dengan URL lagu MP3 pilihanmu.
